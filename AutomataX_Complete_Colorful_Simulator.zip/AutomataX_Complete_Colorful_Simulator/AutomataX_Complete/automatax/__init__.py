"""AutomataX: interactive Automata Theory learning simulator."""
