
import math
import pygame

from .logic import parse_language, check_string, trace_for

W, H = 1180, 760

BG = (10, 15, 32)
PANEL = (19, 27, 52)
PANEL2 = (25, 36, 66)
WHITE = (237, 243, 255)
MUTED = (145, 162, 195)
CYAN = (55, 220, 235)
PURPLE = (166, 111, 255)
PINK = (255, 100, 180)
GREEN = (73, 230, 164)
ORANGE = (255, 190, 83)
RED = (255, 100, 115)
BLUE = (85, 150, 255)


class AutomataXApp:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption(
            "AutomataX | Interactive Automata Theory Studio"
        )
        self.screen = pygame.display.set_mode(
            (W, H), pygame.RESIZABLE
        )
        self.clock = pygame.time.Clock()

        self.font = pygame.font.SysFont("segoeui", 16)
        self.small = pygame.font.SysFont("segoeui", 13)
        self.med = pygame.font.SysFont("segoeui", 20, bold=True)
        self.big = pygame.font.SysFont("segoeui", 29, bold=True)

        # Only two modules
        self.tab = "PDA SIMULATOR"

        self.lang = "0^n1^(2n)"
        self.word = "001111"
        self.pump_text = "001111"
        self.pump_p = "3"

        # UI field names mapped to actual attributes
        self.field_map = {
            "lang": "lang",
            "word": "word",
            "pumpword": "pump_text",
            "pval": "pump_p",
        }

        self.focus = None
        self.spec = parse_language(self.lang)
        self.trace = trace_for(self.word, self.spec)
        self.step = 0

        self.status = "Ready - enter a language and string."
        self.status_color = CYAN
        self.running = True
        self.hitboxes = {}

    def text(self, value, x, y, color=WHITE, font=None):
        surface = (font or self.font).render(
            str(value), True, color
        )
        self.screen.blit(surface, (x, y))
        return surface.get_width()

    def panel(self, rect, color=PANEL, radius=16, border=None):
        pygame.draw.rect(
            self.screen, color, rect, border_radius=radius
        )
        if border:
            pygame.draw.rect(
                self.screen, border, rect, 1,
                border_radius=radius
            )

    def button(self, key, label, rect, color=PURPLE):
        self.panel(rect, color, 10)
        font = self.small if rect.width < 105 else self.font
        surface = font.render(label, True, WHITE)
        self.screen.blit(
            surface, surface.get_rect(center=rect.center)
        )
        self.hitboxes[key] = pygame.Rect(rect)

    def field(self, key, label, value, rect):
        self.text(label, rect.x, rect.y - 23, MUTED, self.small)

        border = CYAN if self.focus == key else (58, 75, 112)
        self.panel(rect, (13, 20, 40), 9, border)

        shown = str(value)
        if self.focus == key:
            shown += "|"

        # Clip long input to the field width
        available_width = rect.width - 24
        while shown and self.font.size(shown)[0] > available_width:
            shown = shown[1:]

        self.text(shown, rect.x + 12, rect.y + 11, WHITE, self.font)
        self.hitboxes[key] = pygame.Rect(rect)

    def state_node(self, name, pos, color, active=False, subtitle=""):
        x, y = pos
        radius = 35

        pygame.draw.circle(
            self.screen,
            color if active else (37, 52, 86),
            (x, y), radius
        )
        pygame.draw.circle(
            self.screen, WHITE if active else color,
            (x, y), radius, 3 if active else 2
        )

        if name in ("q_accept", "MATCH"):
            pygame.draw.circle(
                self.screen, GREEN, (x, y), radius - 6, 2
            )

        surface = self.small.render(name, True, WHITE)
        self.screen.blit(
            surface, surface.get_rect(center=(x, y - 3))
        )

        if subtitle:
            sub = self.small.render(subtitle, True, MUTED)
            self.screen.blit(
                sub, sub.get_rect(center=(x, y + 52))
            )

    def arrow(self, start, end, label, color=MUTED):
        pygame.draw.line(self.screen, color, start, end, 2)

        angle = math.atan2(
            end[1] - start[1],
            end[0] - start[0]
        )
        length = 10
        p1 = (
            end[0] - length * math.cos(angle - 0.5),
            end[1] - length * math.sin(angle - 0.5)
        )
        p2 = (
            end[0] - length * math.cos(angle + 0.5),
            end[1] - length * math.sin(angle + 0.5)
        )
        pygame.draw.polygon(
            self.screen, color, [end, p1, p2]
        )

        mid_x = (start[0] + end[0]) // 2
        mid_y = (start[1] + end[1]) // 2 - 13
        self.text(label, mid_x, mid_y, color, self.small)

    def draw_header(self):
        global W

        self.text("AUTOMATA", 28, 20, CYAN, self.big)
        self.text("X", 185, 20, PURPLE, self.big)
        self.text(
            "INTERACTIVE THEORY STUDIO",
            229, 32, MUTED, self.small
        )

        self.panel(
            pygame.Rect(W - 220, 23, 190, 31),
            PANEL2, 15
        )
        self.text(
            "● LIVE SIMULATION",
            W - 205, 30, GREEN, self.small
        )

        # Challenge Mode removed
        tabs = ["PDA SIMULATOR", "PUMPING LEMMA"]
        widths = {
            "PDA SIMULATOR": 170,
            "PUMPING LEMMA": 170
        }

        x = 28
        for tab in tabs:
            width = widths[tab]
            rect = pygame.Rect(x, 75, width, 37)
            color = PURPLE if self.tab == tab else PANEL2
            self.panel(rect, color, 10)

            surface = self.font.render(tab, True, WHITE)
            self.screen.blit(
                surface, surface.get_rect(center=rect.center)
            )

            self.hitboxes["tab_" + tab] = rect
            x += width + 10

    def current_trace_item(self):
        if not self.trace:
            return {}
        index = min(max(self.step, 0), len(self.trace) - 1)
        return self.trace[index]

    def draw_diagram(self, rect):
        self.panel(rect, PANEL, 16, (47, 65, 105))

        self.text(
            "STATE TRANSITION DIAGRAM",
            rect.x + 20, rect.y + 16, CYAN, self.med
        )
        self.text(
            "The active state is highlighted as the trace advances.",
            rect.x + 20, rect.y + 45, MUTED, self.small
        )

        cy = rect.y + 150
        xs = [
            rect.x + 100, rect.x + 250,
            rect.x + 405, rect.x + 560
        ]

        is_three = self.spec.get("kind") == "three_blocks"

        if is_three:
            names = ["q_start", "q_0", "q_1", "q_2"]
            subtitles = ["start", "read 0s", "read 1s", "read 2s"]
            edge_labels = ["read 0", "read 1", "read 2"]
        else:
            names = ["q_start", "q_0", "q_1", "q_accept"]
            subtitles = ["start", "push 0s", "match 1s", "accept"]
            edge_labels = [
                "0 / push X", "1 / match X", "ε / empty stack"
            ]

        active = self.current_trace_item().get("state", "")

        pygame.draw.line(
            self.screen, MUTED,
            (xs[0] - 70, cy), (xs[0] - 37, cy), 2
        )
        pygame.draw.polygon(
            self.screen, MUTED,
            [
                (xs[0] - 37, cy),
                (xs[0] - 47, cy - 5),
                (xs[0] - 47, cy + 5)
            ]
        )

        colors = [CYAN, BLUE, PURPLE, GREEN]

        for i, (name, x) in enumerate(zip(names, xs)):
            if i < 3:
                self.arrow(
                    (x + 36, cy),
                    (xs[i + 1] - 36, cy),
                    edge_labels[i],
                    CYAN if active == name else MUTED
                )

            self.state_node(
                name, (x, cy), colors[i],
                active == name, subtitles[i]
            )

        if is_three:
            self.panel(
                pygame.Rect(
                    rect.x + 20, rect.y + 235,
                    rect.width - 40, 56
                ),
                (46, 29, 58), 10, (135, 78, 160)
            )
            self.text(
                "THEORETICAL MEMBERSHIP VIEW - NOT A PDA",
                rect.x + 34, rect.y + 246, PINK, self.font
            )
            self.text(
                "0^n1^n2^n is not context-free; a standard PDA cannot recognize it.",
                rect.x + 34, rect.y + 270, MUTED, self.small
            )
        else:
            self.text(
                "STACK (top -> right)",
                rect.x + 25, rect.y + 235, MUTED, self.small
            )
            current = self.current_trace_item()
            stack = current.get("stack", "$") or "ε"
            xx = rect.x + 180

            for ch in stack[-12:]:
                box = pygame.Rect(xx, rect.y + 229, 34, 34)
                self.panel(box, PANEL2, 7, CYAN)
                self.text(ch, xx + 12, rect.y + 237, WHITE, self.font)
                xx += 39

            if len(stack) > 12:
                self.text("...", xx, rect.y + 237, WHITE)

    def draw_pda(self):
        self.text("PDA SIMULATOR", 28, 132, WHITE, self.big)
        self.text(
            "Enter a supported language and input string to inspect the trace.",
            29, 166, MUTED
        )

        self.field(
            "lang", "LANGUAGE PATTERN", self.lang,
            pygame.Rect(28, 218, 360, 43)
        )
        self.field(
            "word", "INPUT STRING", self.word,
            pygame.Rect(405, 218, 280, 43)
        )

        self.button(
            "apply", "Apply language",
            pygame.Rect(704, 218, 145, 43), BLUE
        )
        self.button(
            "run", "Run / validate",
            pygame.Rect(861, 218, 145, 43), PURPLE
        )

        self.button(
            "prev", "Previous",
            pygame.Rect(28, 279, 115, 37), PANEL2
        )
        self.button(
            "next", "Next step",
            pygame.Rect(153, 279, 115, 37), BLUE
        )
        self.button(
            "all", "Run all",
            pygame.Rect(278, 279, 100, 37), PURPLE
        )
        self.button(
            "reset", "Reset",
            pygame.Rect(388, 279, 85, 37), PANEL2
        )

        self.panel(pygame.Rect(495, 279, 511, 37), PANEL2, 9)
        self.text(
            self.status, 508, 289, self.status_color, self.small
        )

        self.draw_diagram(pygame.Rect(28, 337, 978, 330))

        self.panel(
            pygame.Rect(1025, 132, 127, 535),
            PANEL, 16, (47, 65, 105)
        )
        self.text("TRACE", 1042, 151, CYAN, self.med)

        cur = self.current_trace_item()
        self.text(
            f"STEP {self.step + 1}/{max(1, len(self.trace))}",
            1042, 184, MUTED, self.small
        )
        self.text("SYMBOL", 1042, 228, MUTED, self.small)
        self.text(
            cur.get("symbol", "-"), 1042, 250, ORANGE, self.big
        )
        self.text("STATE", 1042, 306, MUTED, self.small)

        state = cur.get("state", "-")
        state_color = (
            GREEN
            if "accept" in state.lower() or state == "MATCH"
            else PURPLE
        )
        self.text(state[:14], 1042, 328, state_color, self.font)

        self.text("STACK", 1042, 382, MUTED, self.small)
        self.text(
            cur.get("stack", "-")[-10:] or "ε",
            1042, 405, CYAN, self.font
        )

        self.text("EXPLANATION", 1042, 464, MUTED, self.small)
        note = cur.get("note", "")
        for i in range(0, min(len(note), 84), 16):
            self.text(
                note[i:i + 16],
                1042, 488 + (i // 16) * 20,
                WHITE, self.small
            )

        self.text("Supported patterns:", 28, 690, MUTED, self.small)
        self.text(
            "0^n1^n | 0^n1^(kn) | 0^n1^n2^n (membership view)",
            150, 690, CYAN, self.small
        )

    def draw_pumping(self):
        self.text("PUMPING LEMMA LAB", 28, 132, WHITE, self.big)
        self.text(
            "Explore pumping behaviour. This is an educational "
            "demonstration, not an automatic proof checker.",
            29, 166, MUTED
        )

        self.field(
            "lang", "LANGUAGE PATTERN", self.lang,
            pygame.Rect(28, 218, 360, 43)
        )
        self.button(
            "apply", "Apply language",
            pygame.Rect(405, 218, 145, 43), BLUE
        )

        self.field(
            "pumpword", "TEST STRING", self.pump_text,
            pygame.Rect(28, 296, 360, 43)
        )
        self.field(
            "pval", "PUMPING LENGTH p", self.pump_p,
            pygame.Rect(405, 296, 170, 43)
        )

        self.button(
            "pumpcheck", "Check string",
            pygame.Rect(590, 296, 145, 43), PURPLE
        )
        self.button(
            "pumpdown", "Pump down (i=0)",
            pygame.Rect(28, 358, 170, 40), PINK
        )
        self.button(
            "pumpup", "Pump up (i=2)",
            pygame.Rect(210, 358, 170, 40), BLUE
        )

        self.panel(
            pygame.Rect(28, 422, 707, 180),
            PANEL, 16, (47, 65, 105)
        )
        self.text(
            "WHAT THIS EXAMPLE TEACHES",
            48, 443, CYAN, self.med
        )

        if self.spec.get("kind") == "three_blocks":
            lines = [
                "L = {0^n1^n2^n | n >= 1} is not context-free.",
                "The CFL pumping lemma splits a long string into uvwxy.",
                "|vwx| <= p and |vx| > 0.",
                "If context-free, every pumped string must remain in L.",
                "This language violates that condition."
            ]
        else:
            lines = [
                "Current language belongs to the 0^n1^(kn) family.",
                "This family is context-free and can be recognized by a PDA.",
                "The regular pumping lemma does not prove non-CFL.",
                "Use 0^n1^n2^n for the non-context-free example.",
                "Pump outputs here are illustrative, not a formal proof."
            ]

        for i, line in enumerate(lines):
            self.text(
                line, 48, 480 + i * 23,
                WHITE if i == 0 else MUTED, self.small
            )

        self.panel(
            pygame.Rect(770, 218, 382, 384),
            PANEL, 16, (47, 65, 105)
        )
        self.text("PUMPING OUTPUT", 792, 240, CYAN, self.med)

        try:
            accepted, reason = check_string(self.pump_text, self.spec)
        except (ValueError, KeyError, TypeError) as error:
            accepted, reason = False, str(error)

        self.text("Original string:", 792, 286, MUTED, self.small)
        self.text(self.pump_text, 792, 308, ORANGE, self.med)
        self.text("Membership:", 792, 357, MUTED, self.small)
        self.text(
            "IN LANGUAGE" if accepted else "NOT IN LANGUAGE",
            792, 380, GREEN if accepted else RED, self.med
        )
        self.text("Analysis:", 792, 430, MUTED, self.small)

        for i in range(0, min(len(reason), 160), 34):
            self.text(
                reason[i:i + 34],
                792, 454 + (i // 34) * 22,
                WHITE, self.small
            )

        self.text(
            "Tip: for 0^n1^n2^n, try 001122 or 000111222.",
            28, 635, ORANGE, self.font
        )

    def render(self):
        global W, H

        W, H = self.screen.get_size()
        self.screen.fill(BG)
        self.hitboxes = {}

        pygame.draw.circle(
            self.screen, (18, 29, 65), (W - 15, 30), 150
        )
        self.draw_header()

        if self.tab == "PDA SIMULATOR":
            self.draw_pda()
        elif self.tab == "PUMPING LEMMA":
            self.draw_pumping()

        pygame.display.flip()

    def apply_language(self):
        try:
            self.spec = parse_language(self.lang)
            self.status = "Language applied: " + self.spec["label"]
            self.status_color = GREEN

            self.trace = trace_for(self.word, self.spec)
            self.step = 0

        except (ValueError, KeyError, TypeError) as error:
            self.status = str(error)
            self.status_color = RED

    def run_check(self):
        try:
            ok, why = check_string(self.word, self.spec)
            self.trace = trace_for(self.word, self.spec)
            self.step = 0
            self.status = (
                "ACCEPTED - " if ok else "REJECTED - "
            ) + why
            self.status_color = GREEN if ok else RED

        except (ValueError, KeyError, TypeError) as error:
            self.status = str(error)
            self.status_color = RED

    def check_pumping_string(self):
        try:
            p = int(self.pump_p)
            if p < 1:
                raise ValueError

            accepted, reason = check_string(
                self.pump_text, self.spec
            )
            self.status = (
                "IN LANGUAGE - " if accepted else "NOT IN LANGUAGE - "
            ) + reason
            self.status_color = GREEN if accepted else RED

        except ValueError:
            self.status = "Pumping length p must be a positive integer."
            self.status_color = RED
        except (KeyError, TypeError) as error:
            self.status = str(error)
            self.status_color = RED

    def handle_click(self, pos):
        for key, rect in list(self.hitboxes.items()):
            if not rect.collidepoint(pos):
                continue

            if key.startswith("tab_"):
                self.tab = key[4:]
                self.focus = None
                return

            if key in ("lang", "word", "pumpword", "pval"):
                self.focus = key
                return

            if key == "apply":
                self.apply_language()
                return

            if key == "run":
                self.run_check()
                return

            if key == "prev":
                self.step = max(0, self.step - 1)
                return

            if key == "next":
                self.step = min(
                    max(0, len(self.trace) - 1), self.step + 1
                )
                return

            if key == "all":
                self.step = max(0, len(self.trace) - 1)
                return

            if key == "reset":
                self.step = 0
                return

            if key == "pumpcheck":
                self.check_pumping_string()
                return

            if key in ("pumpdown", "pumpup"):
                s = self.pump_text
                if len(s) >= 2:
                    cut = max(1, len(s) // 4)
                    start = max(0, (len(s) - cut) // 2)
                    piece = s[start:start + cut]

                    replacement = piece * 2 if key == "pumpup" else ""
                    self.pump_text = (
                        s[:start] + replacement + s[start + cut:]
                    )
                return

    def handle_keydown(self, event):
        if event.key == pygame.K_ESCAPE:
            self.focus = None
            return

        if not self.focus:
            return

        attr = self.field_map.get(self.focus)
        if attr is None:
            self.focus = None
            return

        value = getattr(self, attr)

        if event.key == pygame.K_RETURN:
            self.focus = None
            if self.tab == "PDA SIMULATOR":
                self.run_check()
            return

        if event.key == pygame.K_BACKSPACE:
            setattr(self, attr, value[:-1])
            return

        if (
            event.unicode
            and event.unicode.isprintable()
            and len(value) < 100
        ):
            setattr(self, attr, value + event.unicode)

    def run(self):
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False

                elif event.type == pygame.VIDEORESIZE:
                    self.screen = pygame.display.set_mode(
                        event.size, pygame.RESIZABLE
                    )

                elif event.type == pygame.MOUSEBUTTONDOWN:
                    self.handle_click(event.pos)

                elif event.type == pygame.KEYDOWN:
                    self.handle_keydown(event)

            try:
                self.render()
            except (ValueError, KeyError, TypeError) as error:
                self.screen.fill(BG)
                self.text(
                    "Input error: " + str(error),
                    30, 40, RED, self.font
                )
                self.text(
                    "Press Escape to leave the input field.",
                    30, 75, WHITE, self.font
                )
                pygame.display.flip()

            self.clock.tick(60)

        pygame.quit()
