"""Language parsing and educational checks used by AutomataX.

Supported families:
  0^n1^(kn), n >= 1 (k is a positive integer)
  0^n1^n2^n, n >= 1 (membership demonstration only; not PDA-recognizable)
"""
import re

FAMILY_RE = re.compile(r"^0\^n1\^\((\d+)n\)$")
EQUAL_RE = re.compile(r"^0\^n1\^n$")
THREE_RE = re.compile(r"^0\^n1\^n2\^n$")


def normalize_language(text: str) -> str:
    return re.sub(r"\s+", "", text.strip())


def parse_language(text: str) -> dict:
    raw = normalize_language(text)
    if EQUAL_RE.fullmatch(raw):
        return {"kind": "zero_one", "k": 1, "label": "L = {0ⁿ1ⁿ | n ≥ 1}", "source": raw}
    m = FAMILY_RE.fullmatch(raw)
    if m:
        k = int(m.group(1))
        if not 1 <= k <= 50:
            raise ValueError("Multiplier k must be between 1 and 50.")
        return {"kind": "zero_one", "k": k, "label": f"L = {{0ⁿ1^({k}n) | n ≥ 1}}", "source": raw}
    if THREE_RE.fullmatch(raw):
        return {"kind": "three_blocks", "k": 1, "label": "L = {0ⁿ1ⁿ2ⁿ | n ≥ 1}", "source": raw}
    raise ValueError("Unsupported format. Try 0^n1^n, 0^n1^(2n), or 0^n1^n2^n.")


def check_string(word: str, spec: dict) -> tuple[bool, str]:
    if not word:
        return False, "Enter a non-empty string first."
    if spec["kind"] == "zero_one":
        if not re.fullmatch(r"0+1+", word):
            return False, "Expected one or more 0s followed by one or more 1s, with no other symbols."
        zeros, ones = word.count('0'), word.count('1')
        if ones == spec['k'] * zeros:
            return True, f"There are {zeros} zero(s) and {ones} one(s); ones = {spec['k']} × zeros."
        return False, f"There are {zeros} zero(s) and {ones} one(s); expected {spec['k']} × {zeros} = {spec['k']*zeros} one(s)."
    if not re.fullmatch(r"0+1+2+", word):
        return False, "Expected blocks in order: one or more 0s, then 1s, then 2s."
    a, b, c = word.count('0'), word.count('1'), word.count('2')
    if a == b == c:
        return True, f"All three blocks have length {a}. This string belongs to the language."
    return False, f"Block counts are 0:{a}, 1:{b}, 2:{c}; all three counts must be equal."


def trace_for(word: str, spec: dict) -> list[dict]:
    """Generate a simple educational trace. For 0^n1^kn this is a schematic PDA trace."""
    steps = [{"index": 0, "symbol": "ε", "state": "q_start", "stack": "$", "note": "Start configuration"}]
    stack = ["$"]
    if spec['kind'] == 'zero_one':
        k = spec['k']
        state = 'q_push'
        for i, ch in enumerate(word, 1):
            if ch == '0':
                stack.append('X')
                note = 'Read 0: push one marker X'
                state = 'q_push'
            elif ch == '1':
                # Pop one marker every k ones; this compact stack convention represents the ratio.
                ones_seen = word[:i].count('1')
                if ones_seen % k == 1 and stack[-1:] == ['X']:
                    stack.pop()
                note = f'Read 1: consume part of a group of {k} one(s)'
                state = 'q_match'
            else:
                note = 'Invalid symbol for this language'
                state = 'q_dead'
            steps.append({"index": i, "symbol": ch, "state": state, "stack": ''.join(stack), "note": note})
        accepted, _ = check_string(word, spec)
        steps.append({"index": len(word), "symbol": "ε", "state": 'q_accept' if accepted else 'q_reject', "stack": ''.join(stack), "note": 'Input finished: ' + ('accept' if accepted else 'reject')})
    else:
        # This is explicitly a membership-check trace, not a PDA run: the language is not context-free.
        for i, ch in enumerate(word, 1):
            steps.append({"index": i, "symbol": ch, "state": 'q_0' if ch == '0' else ('q_1' if ch == '1' else 'q_2'), "stack": '—', "note": 'Membership demonstration only; no PDA can recognize this entire language.'})
        accepted, _ = check_string(word, spec)
        steps.append({"index": len(word), "symbol": 'ε', "state": 'MATCH' if accepted else 'NO MATCH', "stack": '—', "note": 'Compare the three block counts.'})
    return steps
