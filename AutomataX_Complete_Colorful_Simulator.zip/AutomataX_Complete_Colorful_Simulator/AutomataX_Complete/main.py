from automatax.ui import AutomataXApp

if __name__ == '__main__':
    AutomataXApp().run()
