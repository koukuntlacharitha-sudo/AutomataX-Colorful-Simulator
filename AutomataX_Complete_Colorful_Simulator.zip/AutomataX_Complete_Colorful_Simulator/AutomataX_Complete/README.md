# AutomataX — Interactive Automata Theory Studio

A colorful Python/Pygame educational desktop simulator with three modules:

- **PDA Simulator** — enter a supported language and any test string, validate membership, inspect a step trace, and view a colorful state-transition diagram with active-state highlighting and stack display.
- **Pumping Lemma Lab** — check membership, set a pumping length, and experiment with illustrative pump-down/pump-up controls. The lab explains the CFL pumping lemma for `0^n1^n2^n` and clearly distinguishes a teaching demonstration from a formal proof checker.
- **Challenge Mode** — quick theory examples with answers.

## Supported language patterns

- `0^n1^n` — equal non-empty blocks of 0s and 1s
- `0^n1^(2n)` through `0^n1^(50n)` — type a positive multiplier, e.g. `0^n1^(3n)`
- `0^n1^n2^n` — membership demonstration only. This language is **not context-free**, so the app correctly does not claim that a PDA can recognize it.

The language input intentionally supports these named families, not arbitrary grammars or regular expressions. The PDA trace for the two-symbol family is an educational schematic, not a formally complete generalized PDA compiler.

## Run on Windows

1. Extract the ZIP.
2. Open the extracted `AutomataX_Complete` folder in VS Code.
3. Open a terminal in that folder and run:

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe main.py
```

If `py` is unavailable, install Python 3.10+ and enable **Add Python to PATH** during setup.

## Try these examples

| Language | String | Expected membership |
|---|---|---|
| `0^n1^n` | `0011` | Accepted |
| `0^n1^(2n)` | `001111` | Accepted |
| `0^n1^(3n)` | `00111111` | Accepted |
| `0^n1^(2n)` | `00111` | Rejected |
| `0^n1^n2^n` | `001122` | In language (membership view; not PDA-recognizable) |
| `0^n1^n2^n` | `0001122` | Not in language |

## Important theory note

`{0^n1^n2^n | n >= 1}` is not context-free. The CFL pumping lemma is a proof technique; this app provides an explanatory illustration, not an exhaustive machine-checked proof over every possible decomposition.
